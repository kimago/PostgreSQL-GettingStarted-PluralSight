﻿CREATE TABLE "OrangeInc"."Employee"
(
  "ID" integer,
  "EmployeeName" character varying(256),
  "Age" integer
)