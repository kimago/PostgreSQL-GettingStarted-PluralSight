﻿INSERT INTO "Customer"(
            "Name", "Birthdate", "Zipcode")
    VALUES ('Mike', 'June 6, 1976', 01256);
INSERT INTO "Customer"(
            "Name", "Birthdate", "Zipcode")
    VALUES ('John', '6 Jan, 1986', 00256);
INSERT INTO "Customer"(
            "Name", "Birthdate", "Zipcode")
    VALUES ('Duke', 'January 16, 1996', 1258);
INSERT INTO "Customer"(
            "Name", "Birthdate", "Zipcode")
    VALUES ('Vikky', '01/01/2001', 00001);
INSERT INTO "Customer"(
            "Name", "Birthdate", "Zipcode")
    VALUES ('Martha', '14/1/76', 01559);
INSERT INTO "Customer"(
            "Name", "Birthdate", "Zipcode")
    VALUES ('Alex', '1/14/76', 01256);
