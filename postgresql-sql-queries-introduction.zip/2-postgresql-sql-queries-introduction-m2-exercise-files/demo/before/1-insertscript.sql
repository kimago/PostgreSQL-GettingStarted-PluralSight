﻿INSERT INTO "Employee"(
            "ID", "EmployeeName", "Age", "Birthdate")
    VALUES (1, 'Mark', 35, '12/1/1975');

INSERT INTO "Employee"(
            "ID", "EmployeeName", "Age", "Birthdate")
    VALUES (2, 'Robert', 35, '12/1/1975');

INSERT INTO "Employee"(
            "ID", "EmployeeName", "Age", "Birthdate","IsCurrentEmployee")
    VALUES (3, 'John', 35, '12/1/1975', B'1');

INSERT INTO "Employee"(
            "ID", "EmployeeName", "Age", "Birthdate")
    VALUES (4, 'Sid', 35, '12/1/1975');


SELECT * 
FROM "Employee";















DELETE
FROM "Employee";