﻿INSERT INTO "Employee"(
            "ID", "EmployeeName", "Age", "Birthdate","IsCurrentEmployee", "MacAddress")
    VALUES (6, 'Spencer', 35, '12/1/1975', B'1','08-00-2b-01-02-03');


SELECT * 
FROM "Employee";