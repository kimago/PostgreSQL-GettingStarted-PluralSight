﻿-- Subtask 1: Delete all rows where first name of actor is Robert


-- Select Data
SELECT *
FROM Actor
WHERE first_name = 'Robert';

-- Delete Clause
DELETE
FROM Actor
WHERE first_name = 'Robert';

-- Select Data
SELECT *
FROM Actor
WHERE first_name = 'Robert';









